package com.example.atleticosrunningteam;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    // Declaramos los componentes de la interfaz
    private TextInputEditText etNombre;
    private MaterialButton btnConectar;
    private TextView tvMensajeRespuesta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Vinculamos cada variable con su ID correspondiente en el XML
        etNombre = findViewById(R.id.etNombre);
        btnConectar = findViewById(R.id.btnConectar);
        tvMensajeRespuesta = findViewById(R.id.tvMensajeRespuesta);

        // Programamos la acción al hacer clic en el botón
        btnConectar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtenemos el texto ingresado en el campo de entrada
                String nombreUsuario = etNombre.getText().toString().trim();

                // Validamos si el campo no está vacío
                if (!nombreUsuario.isEmpty()) {
                    tvMensajeRespuesta.setText("¡Conectado con éxito, " + nombreUsuario + "!");
                } else {
                    tvMensajeRespuesta.setText("Por favor, ingresa tu nombre.");
                }
            }
        });
    }
}